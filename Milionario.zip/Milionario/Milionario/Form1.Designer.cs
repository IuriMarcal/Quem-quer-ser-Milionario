﻿namespace Milionario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.textBoxnome = new System.Windows.Forms.TextBox();
            this.buttonComecar = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.buttonInformacao = new System.Windows.Forms.Button();
            this.textBoxpontuacao = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Milionario.Properties.Resources._30793_34321_65799;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 450);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(12, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(145, 17);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Introduza o seu nome";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.Location = new System.Drawing.Point(665, 9);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(123, 17);
            this.linkLabel2.TabIndex = 2;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Melhor Pontuaçao";
            // 
            // textBoxnome
            // 
            this.textBoxnome.Location = new System.Drawing.Point(15, 40);
            this.textBoxnome.Name = "textBoxnome";
            this.textBoxnome.Size = new System.Drawing.Size(142, 20);
            this.textBoxnome.TabIndex = 3;
            // 
            // buttonComecar
            // 
            this.buttonComecar.BackColor = System.Drawing.Color.Indigo;
            this.buttonComecar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonComecar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonComecar.Location = new System.Drawing.Point(15, 378);
            this.buttonComecar.Name = "buttonComecar";
            this.buttonComecar.Size = new System.Drawing.Size(156, 40);
            this.buttonComecar.TabIndex = 5;
            this.buttonComecar.Text = "Começar";
            this.buttonComecar.UseVisualStyleBackColor = false;
            // 
            // buttonSair
            // 
            this.buttonSair.BackColor = System.Drawing.Color.Indigo;
            this.buttonSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSair.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSair.Location = new System.Drawing.Point(632, 378);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(156, 40);
            this.buttonSair.TabIndex = 6;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = false;
            // 
            // buttonInformacao
            // 
            this.buttonInformacao.BackColor = System.Drawing.Color.Indigo;
            this.buttonInformacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInformacao.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonInformacao.Location = new System.Drawing.Point(15, 177);
            this.buttonInformacao.Name = "buttonInformacao";
            this.buttonInformacao.Size = new System.Drawing.Size(142, 106);
            this.buttonInformacao.TabIndex = 7;
            this.buttonInformacao.Text = "Info \r\nAjudas";
            this.buttonInformacao.UseVisualStyleBackColor = false;
            // 
            // textBoxpontuacao
            // 
            this.textBoxpontuacao.BackColor = System.Drawing.Color.Indigo;
            this.textBoxpontuacao.Location = new System.Drawing.Point(668, 40);
            this.textBoxpontuacao.Multiline = true;
            this.textBoxpontuacao.Name = "textBoxpontuacao";
            this.textBoxpontuacao.Size = new System.Drawing.Size(120, 208);
            this.textBoxpontuacao.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonInformacao);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonComecar);
            this.Controls.Add(this.textBoxpontuacao);
            this.Controls.Add(this.textBoxnome);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.TextBox textBoxnome;
        private System.Windows.Forms.Button buttonComecar;
        private System.Windows.Forms.Button buttonSair;
        private System.Windows.Forms.Button buttonInformacao;
        private System.Windows.Forms.TextBox textBoxpontuacao;
    }
}

